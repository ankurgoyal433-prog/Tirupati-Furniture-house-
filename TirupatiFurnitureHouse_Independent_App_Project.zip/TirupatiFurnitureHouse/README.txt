TIRUPATI FURNITURE HOUSE - INDEPENDENT ANDROID APP PROJECT

This project is a simple Android app that works offline for the product gallery, with Call, WhatsApp and Google Maps buttons requiring internet/apps as appropriate.

Business: Tirupati Furniture House
Location: Abohar, Punjab
Phone: 9256350660 / 9815760724

To build on an Android phone:
1. Install a compatible Android IDE that can import Gradle Android projects.
2. Extract this ZIP and open the TirupatiFurnitureHouse folder as a Gradle project.
3. Allow Gradle sync/downloads.
4. Build the debug APK.
5. Install the generated APK on the phone.

The app content can be edited in app/src/main/assets/index.html.
Photos are in app/src/main/assets/images/.
